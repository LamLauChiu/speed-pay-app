// @flow

import { PluginBuySell, PluginSpend, PluginViewConnect, renderPluginBackButton } from './PluginView.ui'

export { PluginViewConnect as PluginView, PluginBuySell, PluginSpend, renderPluginBackButton }
