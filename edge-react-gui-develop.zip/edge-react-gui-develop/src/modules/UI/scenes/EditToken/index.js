// @flow

import EditToken from './EditTokenConnector'

export default EditToken
