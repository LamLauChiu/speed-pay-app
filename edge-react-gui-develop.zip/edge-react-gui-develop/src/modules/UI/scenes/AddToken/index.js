// @flow

import { AddToken } from './AddToken.ui.js'
import AddTokenConnector from './AddTokenConnector'

export { AddToken }
export default AddTokenConnector
