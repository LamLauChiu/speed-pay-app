// @flow

import Request from './RequestConnector'

export default Request
