// @flow

import { AlertIOS } from 'react-native'
export default {
  alert: (message: string) => AlertIOS.alert(message)
}
