// @flow

import ManageTokens from './ManageTokensConnector.js'

export default ManageTokens
