// @flow

import Recipient from './Recipient.ui.js'

export default Recipient
