/* eslint-disable flowtype/require-valid-file-annotation */

import SearchResults from './SearchResultsConnector'

export default SearchResults
