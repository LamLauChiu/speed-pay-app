/* eslint-disable flowtype/require-valid-file-annotation */

import Slider from './Slider.ui.js'

export default Slider
