// @flow

import WalletListModal from './WalletListModal.ui'

export default WalletListModal
