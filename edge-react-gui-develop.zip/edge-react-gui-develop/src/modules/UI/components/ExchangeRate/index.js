/* eslint-disable flowtype/require-valid-file-annotation */

import ExchangeRate from './ExchangeRate.ui.js'

export default ExchangeRate
