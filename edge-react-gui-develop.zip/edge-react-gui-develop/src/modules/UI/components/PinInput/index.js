// @flow

import PinInput from './PinInput.ui.js'

export default PinInput
