/* eslint-disable flowtype/require-valid-file-annotation */

import RequestStatus from './RequestStatus.ui.js'

export default RequestStatus
