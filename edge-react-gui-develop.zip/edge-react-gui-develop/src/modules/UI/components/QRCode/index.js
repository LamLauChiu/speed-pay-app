// @flow

import QRCode from './QRCode.ui.js'

export default QRCode
