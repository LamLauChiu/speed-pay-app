// @flow

import MaxButton from './MaxButton.ui.js'

export default MaxButton
