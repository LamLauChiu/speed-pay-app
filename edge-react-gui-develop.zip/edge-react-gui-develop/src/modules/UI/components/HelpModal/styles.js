// @flow

import { StyleSheet } from 'react-native'

import THEME from '../../../../theme/variables/airbitz'

export default StyleSheet.create({
  background: {
    backgroundColor: THEME.COLORS.WHITE
  }
})
