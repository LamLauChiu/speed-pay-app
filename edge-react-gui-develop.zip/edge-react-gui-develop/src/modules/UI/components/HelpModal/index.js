// @flow

import HelpModal from './HelpModalConnector'

export default HelpModal
