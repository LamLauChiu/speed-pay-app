// @flow

import ErrorAlert from './ErrorAlertConnector'
export default ErrorAlert
