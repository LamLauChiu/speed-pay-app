/* eslint-disable flowtype/require-valid-file-annotation */

import SafeAreaView from './SafeAreaView.ui.js'

export default SafeAreaView
