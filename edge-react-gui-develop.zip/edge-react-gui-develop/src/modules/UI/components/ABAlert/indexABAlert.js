// @flow

import ABAlert from './ABAlertConnector'
export default ABAlert
