// @flow

import Modal from './Modal.ui'

export default Modal
