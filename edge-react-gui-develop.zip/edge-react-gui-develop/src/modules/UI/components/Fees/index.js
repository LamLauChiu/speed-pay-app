/* eslint-disable flowtype/require-valid-file-annotation */

import Fees from './Fees.ui.js'

export default Fees
