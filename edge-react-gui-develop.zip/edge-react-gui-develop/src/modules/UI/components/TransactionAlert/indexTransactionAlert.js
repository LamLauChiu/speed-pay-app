// @flow

import TransactionAlert from './TransactionAlertConnector'
export default TransactionAlert
