// @flow

import ShareButtons from './ShareButtons.ui.js'

export default ShareButtons
