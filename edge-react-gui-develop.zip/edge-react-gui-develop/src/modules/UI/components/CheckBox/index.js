// @flow

import CheckBox from './CheckBox.ui.js'

export default CheckBox
