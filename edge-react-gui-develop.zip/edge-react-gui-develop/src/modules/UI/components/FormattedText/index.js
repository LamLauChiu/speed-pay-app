// @flow

// The purpose of this file is to create a formatted <Text> component that uses our default styling / theming
import T from './FormattedText.ui.js'

export default T
