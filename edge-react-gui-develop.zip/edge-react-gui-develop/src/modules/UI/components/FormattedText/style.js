// @flow

import THEME from '../../../../theme/variables/airbitz'
export default {
  defaultStyle: {
    fontFamily: THEME.FONTS.DEFAULT
  },
  boldStyle: {
    fontFamily: THEME.FONTS.BOLD
  }
}
