// @flow

import ControlPanel from './ControlPanelConnector'
export default ControlPanel
