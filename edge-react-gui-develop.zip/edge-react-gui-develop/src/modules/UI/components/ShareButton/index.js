// @flow

import ShareButton from './ShareButton.ui.js'

export default ShareButton
