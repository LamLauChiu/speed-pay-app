// @flow

import FlipInput from './FlipInput.ui.js'

export default FlipInput
