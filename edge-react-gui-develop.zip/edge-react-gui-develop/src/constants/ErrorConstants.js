// @flow

export const INSUFFICIENT_FUNDS = 'InsufficientFundsError'
export const DUST = 'Output is dust.'
