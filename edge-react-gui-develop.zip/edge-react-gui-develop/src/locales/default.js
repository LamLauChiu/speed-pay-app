// @flow

import enUS from './en_US'

const strings = {
  enUS
}

export default strings
